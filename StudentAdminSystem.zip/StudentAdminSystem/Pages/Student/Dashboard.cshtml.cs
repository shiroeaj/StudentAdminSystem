using Microsoft.AspNetCore.Mvc.RazorPages;

/* NEW FILE - code-behind for Student Dashboard */
public class StudentDashboardModel : PageModel
{
    public void OnGet()
    {
        // Minimal: extend with real data later.
    }
}
