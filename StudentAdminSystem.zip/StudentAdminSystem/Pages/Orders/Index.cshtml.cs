using Microsoft.AspNetCore.Mvc.RazorPages;

/* NEW FILE - Orders code-behind (minimal) */
public class OrdersIndexModel : PageModel
{
    public void OnGet()
    {
    }
}
