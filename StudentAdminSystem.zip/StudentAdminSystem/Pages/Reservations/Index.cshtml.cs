using Microsoft.AspNetCore.Mvc.RazorPages;

/* NEW FILE - Reservations code-behind (minimal) */
public class ReservationsIndexModel : PageModel
{
    public void OnGet()
    {
    }
}
