using Microsoft.AspNetCore.Mvc.RazorPages;

/* NEW FILE - code-behind for Admin Dashboard
   - Minimal; avoids dependence on your custom services so it compiles cleanly.
*/

public class AdminDashboardModel : PageModel
{
    public void OnGet()
    {
        // Intentionally minimal. Hook into your services here later.
    }
}
