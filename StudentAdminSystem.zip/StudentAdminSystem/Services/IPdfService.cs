﻿namespace StudentAdminSystem.Services
{
    public interface IPdfService
    {
    }
}